#ifndef TERRITORY_H
#define TERRITORY_H

#include <vector>
#include <string>

#include "PeasantFactory.h"
#include "ResourceFactory.h"

/*
#include "Castle.h"
#include "Town.h"
*/

struct ResourceLabourAllocation
{
	std::string name;
	Resource *resource;
	std::vector<Peasant*> peasants;
};

class Territory
{
	private:
		std::string m_name;

	public:
		PeasantFactory	*m_peasantFactory;

		std::vector<Resource*>	m_resources;
		std::vector<Peasant*>	m_peasants;

		std::vector<ResourceLabourAllocation>	m_labourAllocations;

		Territory();
		Territory(const std::string &name);
		Territory(const Territory &other);
		Territory(Territory *other);
		~Territory();

		void					PassSeason();
		void					RandomlyDistributeLabour();
		
		unsigned int			AddResource(Resource *resource);
		unsigned int			AddResources(const unsigned int &num);
		unsigned int			AddResources(std::vector<Resource*> specificResources);
		unsigned int			AddPeasant(Peasant *peasant);
		unsigned int			AddPeasants(const unsigned int &num);	//Adds new peasants to the population, returns total number
		unsigned int			AddPeasants(std::vector<Peasant*> specificPeasants);

		inline std::string		GetName() const { return m_name; }

		inline void				SetName(const std::string &name) { m_name = name; }
};

#endif