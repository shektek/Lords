#ifndef VECTOR2D_H
#define VECTOR2D_H

class Vector2d
{
	public:
		Vector2d() : x(0), y(0){}
		Vector2d(double nx, double ny) : x(nx), y(ny){}

		double x;
		double y;
};

#endif